package com.reativa.part;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
